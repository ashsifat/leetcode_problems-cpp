# Comprehensive Data Structures & Algorithms Guide

## Table of Contents
1. [Introduction](#introduction)
2. [Data Structures](#data-structures)
3. [Algorithms](#algorithms)
4. [Complexity Analysis](#complexity-analysis)
5. [Problem-Solving Patterns](#problem-solving-patterns)
6. [Implementation Examples](#implementation-examples)

## Introduction

Data structures and algorithms are the foundation of computer science and software engineering. **Data structures** organize and store data efficiently, while **algorithms** are step-by-step procedures for solving problems and manipulating data.

### Why They Matter
- **Efficiency**: Proper choice can mean the difference between milliseconds and hours
- **Scalability**: Critical for handling large datasets and high-traffic systems
- **Problem Solving**: Provide proven patterns for common computational challenges
- **Interview Success**: Essential knowledge for technical interviews

---

## Data Structures

### Linear Data Structures

#### Arrays
**What it is**: Contiguous memory blocks storing elements of the same type.

**How it works**: Elements are accessed via indices, with constant-time access due to mathematical address calculation: `address = base + (index × element_size)`.

**Time Complexity**:
- Access: O(1)
- Search: O(n)
- Insertion: O(n) worst case, O(1) at end
- Deletion: O(n) worst case, O(1) at end

**When to use**:
- Need fast random access to elements
- Memory usage is a concern (minimal overhead)
- Implementing other data structures
- Mathematical computations, matrices

**Trade-offs**: Fixed size in many languages, expensive insertions/deletions in middle.

#### Dynamic Arrays (Vectors, ArrayLists)
**What it is**: Resizable arrays that grow automatically.

**How it works**: Maintains an internal array with extra capacity. When full, allocates new array (typically 2x size), copies elements, and deallocates old array.

**Time Complexity**:
- Access: O(1)
- Insertion at end: O(1) amortized, O(n) worst case
- Insertion at middle: O(n)
- Deletion: O(n) for arbitrary position

**When to use**:
- Unknown final size
- Frequent additions to end
- Need array-like access patterns

#### Linked Lists
**What it is**: Nodes containing data and pointers to the next node.

**How it works**: Each node stores data and a reference to the next node. Traversal requires following pointers sequentially.

**Types**:
- **Singly Linked**: Each node points to next
- **Doubly Linked**: Each node has pointers to both next and previous
- **Circular**: Last node points back to first

**Time Complexity**:
- Access: O(n)
- Search: O(n)
- Insertion: O(1) if position known, O(n) to find position
- Deletion: O(1) if position known, O(n) to find position

**When to use**:
- Frequent insertions/deletions at arbitrary positions
- Size varies significantly
- Don't need random access
- Implementing stacks, queues, or other structures

#### Stacks
**What it is**: Last-In-First-Out (LIFO) data structure.

**How it works**: Elements added and removed from the same end (top). Like a stack of plates.

**Operations**:
- Push: Add element to top O(1)
- Pop: Remove top element O(1)
- Peek/Top: View top element without removing O(1)

**When to use**:
- Function call management
- Undo operations
- Expression evaluation
- Backtracking algorithms
- Browser history

**Implementation**: Can use arrays or linked lists as underlying structure.

#### Queues
**What it is**: First-In-First-Out (FIFO) data structure.

**How it works**: Elements added at rear (enqueue) and removed from front (dequeue). Like a line at a store.

**Types**:
- **Simple Queue**: Basic FIFO
- **Circular Queue**: Rear wraps around to front when space available
- **Priority Queue**: Elements have priorities, highest priority dequeued first
- **Deque**: Double-ended queue, insertion/deletion at both ends

**Time Complexity**: O(1) for all basic operations when properly implemented.

**When to use**:
- Task scheduling
- Breadth-first search
- Handling requests in web servers
- Buffer for data streams

### Non-Linear Data Structures

#### Trees
**What it is**: Hierarchical structure with nodes connected by edges, forming parent-child relationships.

**Key Terms**:
- **Root**: Top node with no parent
- **Leaf**: Node with no children
- **Height**: Longest path from root to leaf
- **Depth**: Distance from root to specific node

#### Binary Trees
**How it works**: Each node has at most two children (left and right).

**Types**:
- **Full Binary Tree**: Every node has 0 or 2 children
- **Complete Binary Tree**: All levels filled except possibly last, filled left to right
- **Perfect Binary Tree**: All internal nodes have 2 children, all leaves at same level

**Traversals**:
- **Inorder**: Left → Root → Right
- **Preorder**: Root → Left → Right
- **Postorder**: Left → Right → Root
- **Level-order**: Breadth-first, level by level

#### Binary Search Trees (BST)
**How it works**: Binary tree where left subtree contains values less than root, right subtree contains values greater than root.

**Time Complexity**:
- Search/Insert/Delete: O(log n) average, O(n) worst case (unbalanced)

**When to use**:
- Need sorted data with fast search, insertion, deletion
- Range queries
- Finding min/max efficiently

#### Balanced Binary Search Trees

##### AVL Trees
**How it works**: Self-balancing BST where heights of left and right subtrees differ by at most 1. Rotations maintain balance after operations.

**Time Complexity**: O(log n) guaranteed for all operations.

##### Red-Black Trees
**How it works**: BST with color properties (red/black nodes) that ensure balance. More relaxed balancing than AVL, fewer rotations.

**When to use AVL vs Red-Black**:
- AVL: More lookups than insertions/deletions
- Red-Black: More insertions/deletions, used in many standard libraries

#### Heaps
**What it is**: Complete binary tree satisfying heap property.

**Types**:
- **Max Heap**: Parent ≥ children
- **Min Heap**: Parent ≤ children

**How it works**: Typically implemented as arrays. For index i:
- Parent: (i-1)/2
- Left child: 2i + 1
- Right child: 2i + 2

**Operations**:
- Insert: Add to end, bubble up O(log n)
- Extract-max/min: Remove root, move last to root, bubble down O(log n)
- Build heap: O(n)

**When to use**:
- Priority queues
- Heap sort
- Finding k largest/smallest elements
- Graph algorithms (Dijkstra's, Prim's)

#### Tries (Prefix Trees)
**What it is**: Tree where each path from root represents a string, sharing common prefixes.

**How it works**: Each node represents a character, paths spell out words. Often includes end-of-word markers.

**Time Complexity**:
- Insert/Search/Delete: O(m) where m is string length

**When to use**:
- Autocomplete features
- Spell checkers
- IP routing tables
- Dictionary implementations

#### B-Trees
**What it is**: Self-balancing tree with multiple keys per node, designed for systems with slow disk access.

**How it works**: Nodes can have many children (degree), keeps tree shallow. Used in databases and file systems.

**When to use**:
- Database indexing
- File systems
- Large datasets that don't fit in memory

### Hash-Based Structures

#### Hash Tables
**What it is**: Data structure using hash functions to map keys to array indices.

**How it works**:
1. Hash function converts key to array index
2. Store value at that index
3. Handle collisions with chaining or open addressing

**Collision Resolution**:
- **Chaining**: Store multiple values in linked lists at same index
- **Open Addressing**: Find next available slot (linear probing, quadratic probing, double hashing)

**Time Complexity**:
- Average: O(1) for search, insert, delete
- Worst case: O(n) with many collisions

**When to use**:
- Need fast lookups by key
- Implementing caches
- Counting occurrences
- Database indexing

#### Hash Sets
**What it is**: Hash table storing only keys (no values), for membership testing.

**When to use**:
- Check if element exists
- Remove duplicates
- Set operations (union, intersection)

### Graph Structures

#### Graphs
**What it is**: Collection of vertices (nodes) connected by edges.

**Types**:
- **Directed vs Undirected**: Edges have direction or not
- **Weighted vs Unweighted**: Edges have associated costs/weights
- **Connected vs Disconnected**: All vertices reachable or not
- **Cyclic vs Acyclic**: Contains cycles or not

**Representations**:

##### Adjacency Matrix
- 2D array where matrix[i][j] represents edge from vertex i to j
- Space: O(V²)
- Edge lookup: O(1)
- Good for dense graphs

##### Adjacency List
- Array of lists, each list contains neighbors of a vertex
- Space: O(V + E)
- Edge lookup: O(degree of vertex)
- Good for sparse graphs

**When to use graphs**:
- Social networks
- Transportation systems
- Dependency tracking
- Web page linking
- Game states

---

## Algorithms

### Sorting Algorithms

#### Bubble Sort
**How it works**: Repeatedly steps through list, compares adjacent elements, swaps if wrong order.

**Time Complexity**: O(n²) worst/average, O(n) best case
**Space Complexity**: O(1)
**When to use**: Educational purposes only, very small datasets

#### Selection Sort
**How it works**: Finds minimum element, swaps with first element, repeats for remaining elements.

**Time Complexity**: O(n²) all cases
**Space Complexity**: O(1)
**When to use**: Small datasets where memory writes are expensive

#### Insertion Sort
**How it works**: Builds sorted array one element at a time, inserting each element in correct position.

**Time Complexity**: O(n²) worst/average, O(n) best case
**Space Complexity**: O(1)
**When to use**: Small datasets, nearly sorted data, online sorting

#### Merge Sort
**How it works**: Divide array into halves, recursively sort each half, merge sorted halves.

**Time Complexity**: O(n log n) all cases
**Space Complexity**: O(n)
**When to use**: Need guaranteed O(n log n), stable sort required, external sorting

#### Quick Sort
**How it works**: Choose pivot, partition array around pivot, recursively sort partitions.

**Time Complexity**: O(n log n) average, O(n²) worst case
**Space Complexity**: O(log n) average
**When to use**: General-purpose sorting, in-place sorting needed

#### Heap Sort
**How it works**: Build max heap, repeatedly extract maximum and place at end.

**Time Complexity**: O(n log n) all cases
**Space Complexity**: O(1)
**When to use**: Guaranteed O(n log n) with O(1) space, priority queue applications

### Search Algorithms

#### Linear Search
**How it works**: Check each element sequentially until found or end reached.

**Time Complexity**: O(n)
**When to use**: Unsorted data, small datasets, simple implementation needed

#### Binary Search
**How it works**: Repeatedly divide sorted array in half, compare target with middle element.

**Time Complexity**: O(log n)
**Space Complexity**: O(1) iterative, O(log n) recursive
**When to use**: Sorted data, large datasets, need fast search

**Requirements**: Data must be sorted

### Graph Algorithms

#### Depth-First Search (DFS)
**How it works**: Explores as far as possible along each branch before backtracking.

**Implementation**: Can use recursion or explicit stack.

**Time Complexity**: O(V + E)
**Space Complexity**: O(V)

**When to use**:
- Detecting cycles
- Topological sorting
- Finding connected components
- Maze solving
- Backtracking problems

#### Breadth-First Search (BFS)
**How it works**: Explores all neighbors at current depth before moving to next depth level.

**Implementation**: Uses queue to track nodes to visit.

**Time Complexity**: O(V + E)
**Space Complexity**: O(V)

**When to use**:
- Shortest path in unweighted graphs
- Level-order traversal
- Finding all nodes at distance k
- Social network analysis (degrees of separation)

#### Dijkstra's Algorithm
**How it works**: Finds shortest paths from source to all vertices in weighted graph with non-negative weights.

**Process**:
1. Initialize distances to infinity except source (0)
2. Use priority queue to always process closest unvisited vertex
3. Update distances to neighbors if shorter path found

**Time Complexity**: O((V + E) log V) with binary heap
**When to use**: Shortest path in weighted graphs, GPS navigation, network routing

#### A* Algorithm
**How it works**: Extension of Dijkstra's using heuristic to guide search toward goal.

**Formula**: f(n) = g(n) + h(n)
- g(n): Actual cost from start to n
- h(n): Heuristic estimate from n to goal

**When to use**: Pathfinding in games, robotics, GPS with known destination

### Dynamic Programming

#### What it is
Optimization technique that solves complex problems by breaking them into simpler subproblems, storing results to avoid redundant calculations.

#### Key Concepts
- **Optimal Substructure**: Optimal solution contains optimal solutions to subproblems
- **Overlapping Subproblems**: Same subproblems solved multiple times

#### Approaches
- **Top-down (Memoization)**: Recursive with caching
- **Bottom-up (Tabulation)**: Iterative, build solution from smallest subproblems

#### Classic Problems
- Fibonacci sequence
- Longest Common Subsequence
- Knapsack problems
- Edit distance
- Coin change

**When to use**:
- Optimization problems
- Counting problems
- Decision problems with overlapping subproblems

### Greedy Algorithms

#### What it is
Makes locally optimal choices at each step, hoping to achieve global optimum.

#### Characteristics
- Makes irrevocable decisions
- Never reconsiders previous choices
- Doesn't always produce optimal solution

#### Classic Problems
- Fractional knapsack
- Activity selection
- Huffman coding
- Minimum spanning tree (Kruskal's, Prim's)

**When to use**:
- Problem has greedy choice property
- Need fast approximate solutions
- Optimal substructure exists

### Divide and Conquer

#### What it is
Breaks problem into smaller subproblems, solves recursively, combines results.

#### Steps
1. **Divide**: Break into smaller subproblems
2. **Conquer**: Solve subproblems recursively
3. **Combine**: Merge solutions

#### Examples
- Merge sort
- Quick sort
- Binary search
- Strassen's matrix multiplication

**When to use**:
- Problem can be divided into similar subproblems
- Subproblems are independent
- Combining solutions is efficient

---

## Complexity Analysis

### Big O Notation

#### Time Complexity Classes (Best to Worst)
- **O(1)**: Constant - Hash table access, array indexing
- **O(log n)**: Logarithmic - Binary search, balanced tree operations
- **O(n)**: Linear - Array traversal, linear search
- **O(n log n)**: Linearithmic - Merge sort, heap sort
- **O(n²)**: Quadratic - Bubble sort, nested loops
- **O(n³)**: Cubic - Naive matrix multiplication
- **O(2ⁿ)**: Exponential - Recursive Fibonacci, subset generation
- **O(n!)**: Factorial - Traveling salesman brute force

#### Space Complexity
- **In-place**: O(1) extra space
- **Out-of-place**: Requires additional space proportional to input

#### Amortized Analysis
Average performance over sequence of operations, accounting for expensive operations that occur rarely.

---

## Problem-Solving Patterns

### Two Pointers
**When to use**: Sorted arrays, palindromes, finding pairs with target sum.

**Pattern**: Use two pointers moving toward each other or in same direction.

### Sliding Window
**When to use**: Subarray/substring problems with contiguous elements.

**Pattern**: Maintain window of elements, expand/contract based on conditions.

### Fast and Slow Pointers
**When to use**: Detecting cycles, finding middle elements.

**Pattern**: Two pointers moving at different speeds through structure.

### Backtracking
**When to use**: Finding all solutions, constraint satisfaction problems.

**Pattern**: Build solution incrementally, abandon partial solutions that can't lead to valid complete solution.

### Binary Search Pattern
**When to use**: Sorted data, optimization problems with monotonic property.

**Pattern**: Eliminate half of search space at each step.

---

## Implementation Examples

### Hash Table with Chaining
```python
class HashTable:
    def __init__(self, size=10):
        self.size = size
        self.table = [[] for _ in range(size)]
    
    def _hash(self, key):
        return hash(key) % self.size
    
    def put(self, key, value):
        index = self._hash(key)
        bucket = self.table[index]
        
        for i, (k, v) in enumerate(bucket):
            if k == key:
                bucket[i] = (key, value)
                return
        bucket.append((key, value))
    
    def get(self, key):
        index = self._hash(key)
        bucket = self.table[index]
        
        for k, v in bucket:
            if k == key:
                return v
        raise KeyError(key)
```

### Binary Search Tree
```python
class TreeNode:
    def __init__(self, val=0):
        self.val = val
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None
    
    def insert(self, val):
        if not self.root:
            self.root = TreeNode(val)
        else:
            self._insert_recursive(self.root, val)
    
    def _insert_recursive(self, node, val):
        if val < node.val:
            if not node.left:
                node.left = TreeNode(val)
            else:
                self._insert_recursive(node.left, val)
        else:
            if not node.right:
                node.right = TreeNode(val)
            else:
                self._insert_recursive(node.right, val)
    
    def search(self, val):
        return self._search_recursive(self.root, val)
    
    def _search_recursive(self, node, val):
        if not node or node.val == val:
            return node
        
        if val < node.val:
            return self._search_recursive(node.left, val)
        return self._search_recursive(node.right, val)
```

### Graph Representations
```python
# Adjacency List
class Graph:
    def __init__(self):
        self.graph = {}
    
    def add_edge(self, u, v, weight=1):
        if u not in self.graph:
            self.graph[u] = []
        if v not in self.graph:
            self.graph[v] = []
        
        self.graph[u].append((v, weight))
        # For undirected graph, also add:
        # self.graph[v].append((u, weight))

# Adjacency Matrix
class GraphMatrix:
    def __init__(self, num_vertices):
        self.V = num_vertices
        self.matrix = [[0] * num_vertices for _ in range(num_vertices)]
    
    def add_edge(self, u, v, weight=1):
        self.matrix[u][v] = weight
        # For undirected graph:
        # self.matrix[v][u] = weight
```

---

## Choosing the Right Data Structure

### Decision Framework

#### For Storage and Retrieval
- **Known size, need indexing**: Array
- **Unknown size, frequent appends**: Dynamic Array
- **Frequent insertions/deletions**: Linked List
- **Key-value lookups**: Hash Table
- **Sorted data with range queries**: BST or Balanced Tree

#### For Processing Order
- **LIFO processing**: Stack
- **FIFO processing**: Queue
- **Priority-based processing**: Priority Queue (Heap)

#### For Relationships
- **Hierarchical data**: Trees
- **Network relationships**: Graphs
- **String patterns**: Tries

### Performance Considerations

#### Memory Usage
- Arrays: Minimal overhead
- Linked Lists: Extra pointer storage
- Hash Tables: Load factor affects performance
- Trees: Pointer overhead, potential imbalance

#### Cache Performance
- Arrays: Excellent (spatial locality)
- Linked Lists: Poor (scattered memory)
- Hash Tables: Variable (depends on implementation)

#### Scalability
- Consider how performance degrades with size
- Account for worst-case scenarios
- Factor in concurrent access requirements

---

## Advanced Topics

### Specialized Data Structures

#### Segment Trees
**Purpose**: Range queries and updates on arrays.
**Time Complexity**: O(log n) for queries and updates
**Use cases**: Range sum/min/max queries, competitive programming

#### Fenwick Trees (Binary Indexed Trees)
**Purpose**: Efficient prefix sum calculations.
**Time Complexity**: O(log n) for updates and prefix sum queries
**Use cases**: Cumulative frequency tables, range sum queries

#### Disjoint Set Union (Union-Find)
**Purpose**: Track connected components in dynamic connectivity problems.
**Operations**: Find (which set element belongs to), Union (merge two sets)
**Use cases**: Kruskal's algorithm, percolation, social network analysis

#### LRU Cache
**Purpose**: Cache with Least Recently Used eviction policy.
**Implementation**: Hash table + doubly linked list
**Time Complexity**: O(1) for get and put operations

### String Algorithms

#### KMP (Knuth-Morris-Pratt)
**Purpose**: Efficient pattern matching in strings.
**Time Complexity**: O(n + m) where n is text length, m is pattern length
**Key insight**: Uses preprocessing to avoid redundant comparisons

#### Rabin-Karp
**Purpose**: String matching using rolling hash.
**Advantage**: Can search for multiple patterns simultaneously
**Use case**: Plagiarism detection, DNA sequence analysis

---

## Best Practices

### Code Quality
- Use meaningful variable names
- Add comments for complex logic
- Handle edge cases (empty inputs, null values)
- Write unit tests for critical functions

### Optimization Strategy
1. **First make it work** (correctness)
2. **Then make it right** (clean, maintainable)
3. **Then make it fast** (optimize bottlenecks)

### Common Pitfalls
- **Premature optimization**: Optimize based on actual bottlenecks
- **Wrong data structure choice**: Profile before deciding
- **Ignoring edge cases**: Empty inputs, single elements, maximum sizes
- **Memory leaks**: Especially with dynamic allocation

### Interview Preparation
- Practice implementing core structures from scratch
- Understand time/space trade-offs
- Know when to use each structure/algorithm
- Practice explaining your thought process
- Start with brute force, then optimize

---

## Summary

Mastering data structures and algorithms requires understanding both the theoretical foundations and practical applications. The key is recognizing patterns in problems and matching them to appropriate tools.

**Essential for any programmer**:
- Arrays, Linked Lists, Stacks, Queues
- Hash Tables, Binary Search Trees
- Basic sorting (merge sort, quick sort)
- DFS and BFS for graphs
- Understanding of Big O notation

**Next level mastery**:
- Balanced trees (AVL, Red-Black)
- Advanced graph algorithms (Dijkstra's, A*)
- Dynamic programming patterns
- String algorithms for text processing

Remember: the best data structure or algorithm is the one that solves your specific problem efficiently while remaining maintainable and understandable to your team.