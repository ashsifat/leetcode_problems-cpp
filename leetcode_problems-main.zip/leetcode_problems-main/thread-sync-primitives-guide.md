# Thread Synchronization Primitives Guide

## 🔒 **Mutex (Mutual Exclusion)**

### Principle
A mutex is a lock that ensures only one thread can access a resource at a time.

### How It Works
- **Lock**: Thread acquires exclusive access
- **Unlock**: Thread releases access
- Other threads block until mutex is available

### When to Use
- Protecting shared data from concurrent modification
- Critical sections that must execute atomically
- Read-modify-write operations

### Example Situations
```cpp
// Protecting bank account balance
mutex m;
void withdraw(int amount) {
    lock_guard<mutex> lock(m);
    if (balance >= amount)
        balance -= amount;
}
```

### ✅ Best For
- Simple mutual exclusion
- RAII with lock_guard
- Short critical sections

### ❌ Limitations
- Can cause deadlock if not careful
- No built-in ordering/signaling

---

## 🚦 **Condition Variable**

### Principle
Allows threads to wait for a specific condition to become true, working with a mutex.

### How It Works
- **Wait**: Release mutex and sleep until notified
- **Notify**: Wake up waiting threads
- Always used with a mutex and predicate

### When to Use
- Producer-consumer patterns
- Waiting for state changes
- Complex coordination between threads

### Example Situations
```cpp
// Producer-Consumer Queue
mutex m;
condition_variable cv;
queue<int> q;

// Consumer waits for data
unique_lock<mutex> lock(m);
cv.wait(lock, []{ return !q.empty(); });

// Producer signals data available
q.push(data);
cv.notify_one();
```

### ✅ Best For
- Event-based synchronization
- Multiple waiters
- Complex conditions

### ❌ Limitations
- Spurious wakeups require predicates
- More complex than simple locks

---

## 🎯 **Semaphore**

### Principle
A counter that controls access to a limited number of resources.

### How It Works
- **Acquire/P/Wait**: Decrement counter (block if 0)
- **Release/V/Signal**: Increment counter
- Can allow N threads simultaneously (counting semaphore)

### When to Use
- Limiting concurrent access (e.g., connection pool)
- Signaling between threads
- Producer-consumer with buffer size limits

### Example Situations
```cpp
// Binary Semaphore (like mutex)
counting_semaphore<1> sem{1};

// Counting Semaphore (resource pool)
counting_semaphore<10> connections{10};  // Max 10 connections

// Signaling
counting_semaphore<1> ready{0};  // Start at 0
// Thread A: ready.release();     // Signal ready
// Thread B: ready.acquire();     // Wait for signal
```

### ✅ Best For
- Resource counting
- Simple signaling
- Thread sequencing

### ❌ Limitations
- No ownership concept
- Can't identify which thread has resource

---

## ⚡ **Atomic Variable**

### Principle
Variables that guarantee atomic (indivisible) operations without locks.

### How It Works
- Hardware-level atomic instructions
- No explicit locking needed
- Memory ordering guarantees

### When to Use
- Simple shared counters
- Lock-free data structures
- Flags for thread coordination
- Performance-critical code

### Example Situations
```cpp
// Simple counter
atomic<int> counter{0};
counter++;  // Thread-safe increment

// Flag for shutdown
atomic<bool> done{false};
while (!done) { /* work */ }

// Lock-free stack (advanced)
atomic<Node*> head;
```

### ✅ Best For
- Single variables
- High-performance scenarios
- Avoiding lock overhead
- Simple flags/counters

### ❌ Limitations
- Complex for multiple variables
- Memory ordering complexity
- Possible ABA problems

---

## 📊 **Quick Decision Matrix**

| Scenario | Best Choice | Why |
|----------|------------|-----|
| Protect critical section | **Mutex** | Simple exclusive access |
| Wait for condition | **Condition Variable** | Event-based waiting |
| N resources available | **Semaphore** | Built-in counting |
| Thread A → B sequencing | **Semaphore** | Clean signaling |
| Simple counter/flag | **Atomic** | Lock-free performance |
| Producer-consumer | **CV + Mutex** | Complex coordination |
| Spinlock/busy-wait | **Atomic** | Minimal latency |
| Reader-writer lock | **shared_mutex** | Multiple readers OK |

---

## 🎭 **Common Patterns**

### Thread Sequencing
```cpp
semaphore s{0};
// Thread 1: work(); s.release();
// Thread 2: s.acquire(); work();
```

### Producer-Consumer
```cpp
mutex m; condition_variable cv; queue q;
// Producer: lock, push, notify
// Consumer: lock, wait for !empty, pop
```

### Double-Checked Locking
```cpp
atomic<bool> initialized{false};
if (!initialized) {
    lock_guard lock(m);
    if (!initialized) {
        // Initialize
        initialized = true;
    }
}
```

### Resource Pool
```cpp
counting_semaphore<N> pool{N};
// Acquire resource: pool.acquire()
// Release resource: pool.release()
```

---

## 🚨 **Key Principles**

1. **Mutex**: "I need exclusive access"
2. **CV**: "Wake me when X happens"  
3. **Semaphore**: "Only N threads allowed"
4. **Atomic**: "This must happen in one step"

## 🎯 **Rules of Thumb**

- Start with **mutex** for basic protection
- Add **CV** when threads need to wait for events
- Use **semaphore** for counting/signaling
- Use **atomic** for single variables when performance matters
- Always prefer higher-level abstractions when possible
- Test with thread sanitizer (TSAN)

---

## 🔄 **Memory Ordering (Atomic)**

### Relaxed
- No synchronization between threads
- Only atomicity guaranteed
- `counter.fetch_add(1, memory_order_relaxed)`

### Acquire-Release
- Synchronizes memory between threads
- Release: All writes before are visible to acquire
- `flag.store(true, memory_order_release)`
- `flag.load(memory_order_acquire)`

### Sequential Consistency (Default)
- Total order across all threads
- Most restrictive, safest
- `atomic_var++`  // Uses seq_cst by default

---

## 🎨 **Visual Comparison**

```
Mutex:          [Thread A: Lock ████████ Unlock] [Thread B: Lock ████ Unlock]
                           ↑─── Exclusive ───↑

Semaphore(2):   [Thread A: ████████] 
                [Thread B:     ████████]  (2 concurrent)
                [Thread C:          ████████]

Condition Var:  [Thread A: Wait...........Wakeup████]
                [Thread B:        Signal↗]

Atomic:         [Thread A: Read│Write]
                [Thread B:  Read│Write]  (No blocking)
```

---

## 🚀 **Performance Hierarchy**

1. **Atomic** (fastest) - No OS involvement
2. **Spinlock** - Busy wait on atomic
3. **Mutex** - OS scheduling
4. **Condition Variable** - Complex coordination
5. **Multiple Mutexes** (slowest) - Deadlock risks

---

## 📝 **Deadlock Prevention**

1. **Lock Ordering**: Always acquire in same order
2. **Lock Timeout**: Use try_lock_for()
3. **Avoid Nested Locks**: Minimize lock scope
4. **std::lock()**: Lock multiple mutexes atomically

```cpp
// Deadlock-free multiple locks
std::lock(m1, m2, m3);
lock_guard<mutex> l1(m1, adopt_lock);
lock_guard<mutex> l2(m2, adopt_lock);
lock_guard<mutex> l3(m3, adopt_lock);
```

---

## 🎓 **Interview Quick Reference**

| Problem Type | Go-To Solution |
|--------------|----------------|
| Basic protection | `lock_guard<mutex>` |
| Timed wait | `cv.wait_for()` |
| N resources | `counting_semaphore<N>` |
| Sequence A→B→C | Chain of semaphores |
| Reader-writer | `shared_mutex` |
| Once-only init | `std::once_flag` |
| Thread-local | `thread_local` |

---

## 💡 **Modern C++ Features**

### C++11
- `mutex`, `lock_guard`, `unique_lock`
- `condition_variable`
- `atomic<T>`
- `thread`

### C++14
- `shared_timed_mutex`

### C++17
- `shared_mutex`
- `scoped_lock` (multiple mutexes)

### C++20
- `counting_semaphore`, `binary_semaphore`
- `latch`, `barrier`
- `atomic::wait()`, `atomic::notify_one()`
- `jthread` (auto-joining thread)