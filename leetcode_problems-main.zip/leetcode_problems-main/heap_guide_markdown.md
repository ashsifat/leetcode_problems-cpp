# 📚 The Complete Heap Data Structure Guide

## Table of Contents
1. [What is a Heap?](#what-is-a-heap)
2. [Types of Heaps](#types-of-heaps)
3. [Heap Properties](#heap-properties)
4. [Array Representation](#array-representation)
5. [Core Operations](#core-operations)
6. [Implementation in C++](#implementation-in-c)
7. [STL Priority Queue](#stl-priority-queue)
8. [Common Heap Problems](#common-heap-problems)
9. [Time & Space Complexity](#time--space-complexity)
10. [Tips and Tricks](#tips-and-tricks)

---

## What is a Heap?

A **heap** is a complete binary tree that satisfies the heap property. It's an efficient data structure for priority queue operations.

### Key Characteristics:
- **Complete Binary Tree**: All levels filled except possibly the last
- **Heap Property**: Parent-child relationship follows specific ordering
- **Efficient**: O(log n) insertion and deletion
- **No Pointers Needed**: Can be stored in an array

---

## Types of Heaps

### 1. Max Heap
- Parent ≥ Children
- Root is the maximum element
- Used for: Finding maximum, priority queues with highest priority first

```
       90
      /  \
    70    50
   / \   /
  40 30 20
```

### 2. Min Heap
- Parent ≤ Children  
- Root is the minimum element
- Used for: Finding minimum, Dijkstra's algorithm, Huffman coding

```
       10
      /  \
    20    30
   / \   /
  40 50 60
```

---

## Heap Properties

### 1. Complete Binary Tree Property
- All levels are completely filled except possibly the last level
- Last level is filled from left to right

### 2. Heap Order Property
- **Max Heap**: `parent ≥ max(left_child, right_child)`
- **Min Heap**: `parent ≤ min(left_child, right_child)`

### 3. Height Property
- Height of heap with n nodes: **⌊log₂n⌋**
- This ensures O(log n) operations

---

## Array Representation

Heaps are typically stored in arrays for efficiency:

```
Tree:        50
           /    \
         30      40
        / \     /
       10  20  15

Array: [50, 30, 40, 10, 20, 15]
Index:  0   1   2   3   4   5
```

### Index Formulas (0-based indexing):
- **Parent of i**: `(i - 1) / 2`
- **Left child of i**: `2 * i + 1`
- **Right child of i**: `2 * i + 2`

### Index Formulas (1-based indexing):
- **Parent of i**: `i / 2`
- **Left child of i**: `2 * i`
- **Right child of i**: `2 * i + 1`

---

## Core Operations

### 1. Insert (Push) - O(log n)
```cpp
void insert(int val) {
    heap.push_back(val);        // Add to end
    int index = heap.size() - 1;
    
    // Bubble up (heapify up)
    while (index > 0) {
        int parent = (index - 1) / 2;
        if (heap[parent] >= heap[index]) break;  // Max heap
        swap(heap[parent], heap[index]);
        index = parent;
    }
}
```

### 2. Extract Max/Min (Pop) - O(log n)
```cpp
int extractMax() {
    if (heap.empty()) return -1;
    
    int maxVal = heap[0];           // Save max
    heap[0] = heap.back();          // Move last to root
    heap.pop_back();                // Remove last
    
    // Bubble down (heapify down)
    int index = 0;
    while (true) {
        int largest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;
        
        if (left < heap.size() && heap[left] > heap[largest])
            largest = left;
        if (right < heap.size() && heap[right] > heap[largest])
            largest = right;
            
        if (largest == index) break;
        swap(heap[index], heap[largest]);
        index = largest;
    }
    
    return maxVal;
}
```

### 3. Peek - O(1)
```cpp
int peek() {
    return heap.empty() ? -1 : heap[0];
}
```

### 4. Build Heap - O(n)
```cpp
void buildHeap(vector<int>& arr) {
    heap = arr;
    // Start from last non-leaf node
    for (int i = heap.size() / 2 - 1; i >= 0; i--) {
        heapifyDown(i);
    }
}
```

---

## Implementation in C++

### Complete Max Heap Class
```cpp
class MaxHeap {
private:
    vector<int> heap;
    
    void heapifyUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;
            if (heap[parent] >= heap[index]) break;
            swap(heap[parent], heap[index]);
            index = parent;
        }
    }
    
    void heapifyDown(int index) {
        while (true) {
            int largest = index;
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            
            if (left < heap.size() && heap[left] > heap[largest])
                largest = left;
            if (right < heap.size() && heap[right] > heap[largest])
                largest = right;
                
            if (largest == index) break;
            swap(heap[index], heap[largest]);
            index = largest;
        }
    }
    
public:
    void push(int val) {
        heap.push_back(val);
        heapifyUp(heap.size() - 1);
    }
    
    int pop() {
        if (heap.empty()) return -1;
        
        int maxVal = heap[0];
        heap[0] = heap.back();
        heap.pop_back();
        
        if (!heap.empty()) {
            heapifyDown(0);
        }
        
        return maxVal;
    }
    
    int top() {
        return heap.empty() ? -1 : heap[0];
    }
    
    int size() {
        return heap.size();
    }
    
    bool empty() {
        return heap.empty();
    }
};
```

---

## STL Priority Queue

C++ STL provides `priority_queue` which is a heap implementation:

### Max Heap (Default)
```cpp
#include <queue>

priority_queue<int> maxHeap;

// Operations
maxHeap.push(5);        // Insert
int top = maxHeap.top(); // Peek
maxHeap.pop();          // Remove top
int size = maxHeap.size();
bool isEmpty = maxHeap.empty();
```

### Min Heap
```cpp
// Method 1: Using greater<int>
priority_queue<int, vector<int>, greater<int>> minHeap;

// Method 2: Negate values (for max heap)
priority_queue<int> maxHeap;
maxHeap.push(-5);  // Insert 5 as -5
int val = -maxHeap.top();  // Get actual value
```

### Custom Comparator
```cpp
// Custom struct
struct Task {
    int priority;
    string name;
};

// Comparator
struct CompareTask {
    bool operator()(Task& t1, Task& t2) {
        return t1.priority < t2.priority;  // Max heap by priority
    }
};

priority_queue<Task, vector<Task>, CompareTask> taskQueue;
```

### Using Lambda (C++11+)
```cpp
auto cmp = [](int a, int b) { return a > b; };  // Min heap
priority_queue<int, vector<int>, decltype(cmp)> minHeap(cmp);
```

---

## Common Heap Problems

### 1. K Largest/Smallest Elements
```cpp
vector<int> findKLargest(vector<int>& nums, int k) {
    priority_queue<int, vector<int>, greater<int>> minHeap;
    
    for (int num : nums) {
        minHeap.push(num);
        if (minHeap.size() > k) {
            minHeap.pop();  // Remove smallest
        }
    }
    
    vector<int> result;
    while (!minHeap.empty()) {
        result.push_back(minHeap.top());
        minHeap.pop();
    }
    return result;
}
```

### 2. Merge K Sorted Lists
```cpp
struct ListNode {
    int val;
    ListNode* next;
};

ListNode* mergeKLists(vector<ListNode*>& lists) {
    auto cmp = [](ListNode* a, ListNode* b) {
        return a->val > b->val;  // Min heap
    };
    priority_queue<ListNode*, vector<ListNode*>, decltype(cmp)> minHeap(cmp);
    
    // Add first node of each list
    for (auto list : lists) {
        if (list) minHeap.push(list);
    }
    
    ListNode dummy(0);
    ListNode* tail = &dummy;
    
    while (!minHeap.empty()) {
        ListNode* node = minHeap.top();
        minHeap.pop();
        
        tail->next = node;
        tail = tail->next;
        
        if (node->next) {
            minHeap.push(node->next);
        }
    }
    
    return dummy.next;
}
```

### 3. Median from Data Stream
```cpp
class MedianFinder {
    priority_queue<int> maxHeap;  // Left half
    priority_queue<int, vector<int>, greater<int>> minHeap;  // Right half
    
public:
    void addNum(int num) {
        maxHeap.push(num);
        
        // Balance: move max of left to right
        minHeap.push(maxHeap.top());
        maxHeap.pop();
        
        // Ensure maxHeap has same or 1 more element
        if (maxHeap.size() < minHeap.size()) {
            maxHeap.push(minHeap.top());
            minHeap.pop();
        }
    }
    
    double findMedian() {
        if (maxHeap.size() > minHeap.size()) {
            return maxHeap.top();
        }
        return (maxHeap.top() + minHeap.top()) / 2.0;
    }
};
```

### 4. Last Stone Weight (LeetCode 1046)
```cpp
int lastStoneWeight(vector<int>& stones) {
    priority_queue<int> maxHeap(stones.begin(), stones.end());
    
    while (maxHeap.size() > 1) {
        int first = maxHeap.top(); maxHeap.pop();
        int second = maxHeap.top(); maxHeap.pop();
        
        if (first != second) {
            maxHeap.push(first - second);
        }
    }
    
    return maxHeap.empty() ? 0 : maxHeap.top();
}
```

---

## Time & Space Complexity

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Insert | O(log n) | O(1) |
| Extract Max/Min | O(log n) | O(1) |
| Peek | O(1) | O(1) |
| Build Heap | O(n) | O(n) |
| Heapify | O(log n) | O(1) |
| Search | O(n) | O(1) |
| Delete arbitrary | O(n) | O(1) |

### Why Build Heap is O(n)?
- Nodes at level i: 2^i nodes
- Height from level i: h - i
- Work at level i: 2^i * (h - i)
- Total work: Σ(2^i * (h - i)) = O(n)

---

## Tips and Tricks

### 1. Choosing Between Min and Max Heap
- **K largest**: Use min heap of size k
- **K smallest**: Use max heap of size k
- **Median**: Use two heaps (max for left, min for right)

### 2. Common Patterns
```cpp
// Pattern 1: K elements
// Keep heap size = k, top will be kth largest/smallest

// Pattern 2: Merge sorted sequences
// Use min heap with custom comparator

// Pattern 3: Running median
// Two heaps: maxHeap (left half) + minHeap (right half)

// Pattern 4: Priority scheduling
// Custom comparator based on priority
```

### 3. Heap vs Sort
- Use heap when:
  - Need only k elements (not all)
  - Dynamic data (streaming)
  - Need to maintain order during insertions
  
- Use sorting when:
  - Need all elements sorted
  - One-time operation
  - No further insertions

### 4. Memory Optimization
```cpp
// Reserve space if size is known
priority_queue<int, vector<int>> pq;
pq.reserve(1000);  // Won't work directly

// Workaround:
vector<int> container;
container.reserve(1000);
priority_queue<int, vector<int>, greater<int>> pq(
    greater<int>(), move(container)
);
```

### 5. Debugging Tips
- Print heap as array to verify heap property
- Check parent-child relationships
- Verify complete tree property
- Test with edge cases: empty, single element, duplicates

---

## Practice Problems

### Easy
1. **Kth Largest Element** (LeetCode 215)
2. **Last Stone Weight** (LeetCode 1046)
3. **K Closest Points to Origin** (LeetCode 973)

### Medium
4. **Top K Frequent Elements** (LeetCode 347)
5. **Merge K Sorted Lists** (LeetCode 23)
6. **Find Median from Data Stream** (LeetCode 295)
7. **Task Scheduler** (LeetCode 621)

### Hard
8. **Sliding Window Median** (LeetCode 480)
9. **IPO** (LeetCode 502)
10. **Trapping Rain Water II** (LeetCode 407)

---

## Quick Reference

```cpp
// Max Heap
priority_queue<int> maxHeap;

// Min Heap
priority_queue<int, vector<int>, greater<int>> minHeap;

// Custom Type
priority_queue<pair<int,int>> pq;  // Compares by first element

// With Lambda
auto cmp = [](int a, int b) { return a > b; };
priority_queue<int, vector<int>, decltype(cmp)> heap(cmp);

// Common Operations
heap.push(x);    // Insert
heap.top();      // Peek
heap.pop();      // Remove top
heap.size();     // Size
heap.empty();    // Check empty
```

---

## Summary

Heaps are essential for:
- **Priority queue operations**
- **Finding k largest/smallest elements**
- **Merging sorted sequences**
- **Real-time median tracking**
- **Graph algorithms** (Dijkstra, Prim's)

Master heaps to efficiently solve problems requiring:
- Dynamic ordering
- Partial sorting
- Priority-based processing

---

*Happy Coding! 🚀*