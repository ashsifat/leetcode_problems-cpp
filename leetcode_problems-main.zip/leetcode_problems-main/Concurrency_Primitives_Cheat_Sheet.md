# Concurrency Primitives Cheat Sheet (C++): Mutex, Condition Variable, Semaphores, Atomics

> A practical, interview-ready guide with principles, when-to-use, pitfalls, and tiny C++ examples.

---

## TL;DR — Pick the right tool

| Primitive | Core idea | Use when… | Pros | Cons / Pitfalls |
|---|---|---|---|---|
| **Mutex** | Mutual exclusion for a critical section | You need to protect shared data from concurrent access | Simple, safe, expressive | Deadlocks, priority inversion, hold-time matters |
| **Condition Variable (CV)** | Sleep until a **predicate on shared state** becomes true | A thread must **wait** for a state change (e.g., “queue not empty”) | No busy-wait; precise | Must pair with mutex + predicate; spurious wakeups |
| **Semaphore** | **Permits counter**; acquire/decrement, release/increment | Limit concurrency, count resources, or cross-process sync | No missed signals; great for N-parallelism | Over/under-release bugs; still need a mutex for data |
| **Atomic** | Indivisible ops + memory ordering | Simple counters/flags, lock-free queues, fast paths | Very fast; no lock | Easy to misuse memory order; busy-wait; tricky to reason about |

---

## 1) Mutex (Mutual Exclusion)

**Principle:** At most one thread owns the lock → only that thread touches the protected data.  
**Invariants:** Every read/write of protected state happens **while holding the same mutex**.

**Key APIs (C++):**
- `std::mutex`, `std::lock_guard<std::mutex>` (RAII), `std::unique_lock<std::mutex>` (unlock/relock, timed waits)
- `std::scoped_lock` (lock multiple without deadlock)
- Avoid `std::recursive_mutex` unless you truly need re-entrancy.

**Patterns & tips:**
- Keep critical sections **small**; don’t call unknown/slow code while holding the lock.
- **Deadlock avoidance:** consistent lock ordering, or lock multiple with `std::scoped_lock m1,m2`.
- **Priority inversion:** OS may or may not help (priority inheritance). Keep hold time short.

**Example — thread-safe counter**
```cpp
#include <mutex>

struct Counter {
  std::mutex m;
  long long value = 0;
  void inc() {
    std::lock_guard<std::mutex> lk(m);
    ++value;
  }
  long long get() {
    std::lock_guard<std::mutex> lk(m);
    return value;
  }
};
```

---

## 2) Condition Variable (CV)

**Principle:** Sleep until a **condition** on shared state is true.  
You must use a mutex to protect that state; `wait()` **atomically**: *unlock → sleep → re-lock*.

**Rules of thumb:**
- Always wait in a **loop with a predicate** due to **spurious wakeups**:
  ```cpp
  cv.wait(lock, [&]{ return condition(); });
  ```
- Update state **under the lock**, then `notify_one()` or `notify_all()`.  
  Notifying while holding or just after releasing both work; doing it after releasing can reduce contention.

**When to use:** producer/consumer, “wait until X happens,” barrier-like coordination.

**Example — bounded queue (mutex + CV)**
```cpp
#include <mutex>
#include <condition_variable>
#include <queue>

template<class T>
class BoundedQueue {
  std::mutex m;
  std::condition_variable cv_not_full, cv_not_empty;
  std::queue<T> q;
  const size_t cap;
public:
  explicit BoundedQueue(size_t c) : cap(c) {}

  void push(T x) {
    std::unique_lock<std::mutex> lk(m);
    cv_not_full.wait(lk, [&]{ return q.size() < cap; });
    q.push(std::move(x));
    lk.unlock();
    cv_not_empty.notify_one();
  }

  T pop() {
    std::unique_lock<std::mutex> lk(m);
    cv_not_empty.wait(lk, [&]{ return !q.empty(); });
    T v = std::move(q.front()); q.pop();
    lk.unlock();
    cv_not_full.notify_one();
    return v;
  }
};
```

---

## 3) Semaphores

**Principle:** Maintain a **count of permits**. `acquire()` decrements (blocks if zero); `release()` increments and wakes a waiter.

- **Binary semaphore** (0/1) ≈ a simple gate.
- **Counting semaphore** tracks **N** resources (e.g., 4 GPU streams, 8 DB connections).
- Unlike CVs, semaphore increments persist—**no missed wakeups** if a signal comes before the wait.

**C++20:** `std::counting_semaphore<N>` and `std::binary_semaphore`.  
(Or POSIX `sem_t`, or C++ wrappers like `std::counting_semaphore<INT_MAX>`.)

**When to use:** limit concurrency, represent resource availability, pipeline stages with token budgets, producer/consumer (often paired with a mutex for the actual container).

**Example — limit parallel work to `K`**
```cpp
#include <semaphore>
#include <thread>
#include <vector>
#include <iostream>

std::counting_semaphore<> slots(/*initial*/ 4); // allow 4 concurrent tasks

void do_task(int id) {
  slots.acquire();                   // wait for a permit
  // ... critical parallel work (no shared state here) ...
  std::cout << "Task " << id << "\n";
  slots.release();                   // give permit back
}

int main() {
  std::vector<std::thread> ts;
  for (int i = 0; i < 20; ++i) ts.emplace_back(do_task, i);
  for (auto& t : ts) t.join();
}
```

**Pitfalls:**
- **Over-release/under-release** → logical bugs or deadlocks.
- You still need a **mutex** to protect shared containers around the semaphore.
- Fairness is not guaranteed unless your platform provides it.

---

## 4) Atomics

**Principle:** Operations are **indivisible**, and you can control memory visibility with **memory orders**. Enables lock-free/wait-free algorithms.

**Common types:** `std::atomic<int>`, `std::atomic<bool>`, `std::atomic<uint64_t>`, `std::atomic<void*>`, `std::atomic_flag`.

**Memory orders (intuition):**
- `memory_order_relaxed`: atomicity only (no visibility ordering). Great for counters/metrics.
- `memory_order_acquire` / `release`: ensure happens-before around a handoff (producer sets + release; consumer reads + acquire).
- `memory_order_acq_rel`: both sides.
- `memory_order_seq_cst`: strongest, total ordering (simplest mental model, slower).

**Guidelines:**
- Prefer `seq_cst` until you have a proven need to relax and you can **reason about it**.
- Use **`std::atomic<bool>` flags** with acquire/release for ready-ness.
- Busy-wait? Use `std::this_thread::yield()` or exponential backoff to be polite to the scheduler.

**Examples**

*Atomic flag (one-time publish with acquire/release)*:
```cpp
#include <atomic>

std::atomic<bool> ready{false};
int data = 0;

void producer() {
  data = 42;                      // normal write
  ready.store(true, std::memory_order_release);
}

void consumer() {
  while (!ready.load(std::memory_order_acquire)) { /* spin or sleep */ }
  // guaranteed to see data == 42 here
}
```

*Tiny spinlock (avoid in production unless you know it’s right)*:
```cpp
#include <atomic>

class SpinLock {
  std::atomic_flag f = ATOMIC_FLAG_INIT;
public:
  void lock()   { while (f.test_and_set(std::memory_order_acquire)) { /* pause */ } }
  void unlock() { f.clear(std::memory_order_release); }
};
```

**Pitfalls:**
- Mixing atomic and non-atomic accesses to the same object ⇒ **data race**.
- Relaxed orderings can be **correct but useless** if readers never see updates.
- Lock-free ≠ faster under contention; may waste CPU and starve lower-priority threads.

---

## 5) Applying the right primitive (situations)

- **Protecting a shared map/vector**: **Mutex**. Add CV only if threads need to **wait** for state changes.
- **Producer–consumer queue**:
  - Mutex + CV (classic; predicate is `!q.empty()` / `q.size()<cap`).
  - Or **Semaphores**: `items` (count of produced), `spaces` (remaining capacity) + a mutex for the queue.
- **Limit concurrency (N parallel tasks)**: **Counting semaphore** with N permits.
- **Simple flags/counters (hot path)**: **Atomic** (e.g., `fetch_add`, `load/store` with appropriate memory order).
- **One-time initialization**: `std::call_once` + `std::once_flag` (safer than DIY double-checked locking).
- **Cross-process sync**: OS semaphores/futexes; CVs typically within-process.

---

## 6) Two canonical patterns

**A) Producer–consumer with semaphores + mutex**
```cpp
#include <semaphore>
#include <mutex>
#include <queue>

std::counting_semaphore<> items(0);      // produced items
std::counting_semaphore<> spaces(10);    // capacity = 10
std::mutex m;
std::queue<int> q;

void produce(int x) {
  spaces.acquire();
  { std::lock_guard<std::mutex> lk(m); q.push(x); }
  items.release();
}

int consume() {
  items.acquire();
  std::lock_guard<std::mutex> lk(m);
  int v = q.front(); q.pop();
  spaces.release();
  return v;
}
```

**B) Wait for “ready” event (atomics)**
```cpp
#include <atomic>

std::atomic<bool> ready{false};
void signal_ready() { ready.store(true, std::memory_order_release); }
void wait_ready()   { while (!ready.load(std::memory_order_acquire)) {/*spin/sleep*/} }
```

---

## 7) Testing & debugging

- Compile with `-O2 -g -pthread` and run with **Thread Sanitizer** (`-fsanitize=thread`) to catch data races.
- Use timeouts for waits: `cv.wait_for(...)`, `semaphore.try_acquire_for(...)` to avoid permanent hangs in tests.
- Log **state + happens-before** events (who holds which lock, queue sizes, etc.).
- Keep **invariants** near the code (comments or assertions): “`q.size() <= cap`”.

---

## 8) Quick decision flow

1. **Just protect data?** → Mutex.  
2. **Need to sleep until state changes?** → Mutex + CV (with predicate).  
3. **Limit to N concurrent uses / count a resource?** → Counting semaphore (plus mutex for data).  
4. **Trivial counter/flag or lock-free DS?** → Atomics (pick memory order carefully).  
5. **Unsure? Prefer clarity.** Start with mutex/CV; only optimize to semaphores/atomics if profiling proves it.

---

## Further reading (keywords to look up)

- *Mesa monitor problem*, *spurious wakeups*, *priority inversion*, *ABA problem* (atomics), *wait-free vs lock-free*, *happens-before*, *producer–consumer*, *seqlock*, *RCU*.
