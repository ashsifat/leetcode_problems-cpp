# Linked List in C++ – Quick Reference Guide

## 🔧 Basic Structure

```cpp
struct ListNode {
    int val;
    ListNode* next;
    
    // Constructors
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode* next) : val(x), next(next) {}
};

// Alternative template version
template<typename T>
struct Node {
    T data;
    Node<T>* next;
    
    Node(T value) : data(value), next(nullptr) {}
};
```

## 🧱 Creating Nodes

```cpp
// Method 1: Direct creation
ListNode* head = new ListNode(1);
head->next = new ListNode(2);
head->next->next = new ListNode(3);

// Method 2: Using a helper function
ListNode* createList(vector<int>& values) {
    if (values.empty()) return nullptr;
    
    ListNode* head = new ListNode(values[0]);
    ListNode* current = head;
    
    for (int i = 1; i < values.size(); i++) {
        current->next = new ListNode(values[i]);
        current = current->next;
    }
    
    return head;
}

// Usage
vector<int> vals = {1, 2, 3, 4, 5};
ListNode* head = createList(vals);
```

## 🔁 Traversing a Linked List

```cpp
// Method 1: Basic traversal
void printList(ListNode* head) {
    ListNode* current = head;
    while (current != nullptr) {
        cout << current->val << " ";
        current = current->next;
    }
    cout << endl;
}

// Method 2: Count nodes
int countNodes(ListNode* head) {
    int count = 0;
    ListNode* current = head;
    while (current != nullptr) {
        count++;
        current = current->next;
    }
    return count;
}

// Method 3: Find a value
ListNode* findNode(ListNode* head, int target) {
    ListNode* current = head;
    while (current != nullptr) {
        if (current->val == target) {
            return current;
        }
        current = current->next;
    }
    return nullptr; // Not found
}

// Method 4: Get node at specific index
ListNode* getNodeAt(ListNode* head, int index) {
    ListNode* current = head;
    int pos = 0;
    
    while (current != nullptr && pos < index) {
        current = current->next;
        pos++;
    }
    
    return current; // Returns nullptr if index out of bounds
}
```

## ➕ Inserting a Node

### Insert at Beginning
```cpp
ListNode* insertAtBeginning(ListNode* head, int val) {
    ListNode* newNode = new ListNode(val);
    newNode->next = head;
    return newNode; // New head
}
```

### Insert at End
```cpp
ListNode* insertAtEnd(ListNode* head, int val) {
    ListNode* newNode = new ListNode(val);
    
    if (head == nullptr) {
        return newNode;
    }
    
    ListNode* current = head;
    while (current->next != nullptr) {
        current = current->next;
    }
    current->next = newNode;
    
    return head;
}
```

### Insert After a Given Node
```cpp
void insertAfter(ListNode* prevNode, int val) {
    if (prevNode == nullptr) {
        cout << "Previous node cannot be NULL" << endl;
        return;
    }
    
    ListNode* newNode = new ListNode(val);
    newNode->next = prevNode->next;
    prevNode->next = newNode;
}
```

### Insert at Specific Position
```cpp
ListNode* insertAtPosition(ListNode* head, int pos, int val) {
    if (pos == 0) {
        return insertAtBeginning(head, val);
    }
    
    ListNode* current = head;
    for (int i = 0; i < pos - 1 && current != nullptr; i++) {
        current = current->next;
    }
    
    if (current == nullptr) {
        cout << "Position out of bounds" << endl;
        return head;
    }
    
    insertAfter(current, val);
    return head;
}
```

## ❌ Deleting a Node

### Delete First Node
```cpp
ListNode* deleteFirst(ListNode* head) {
    if (head == nullptr) return nullptr;
    
    ListNode* newHead = head->next;
    delete head;
    return newHead;
}
```

### Delete Last Node
```cpp
ListNode* deleteLast(ListNode* head) {
    if (head == nullptr) return nullptr;
    
    if (head->next == nullptr) {
        delete head;
        return nullptr;
    }
    
    ListNode* current = head;
    while (current->next->next != nullptr) {
        current = current->next;
    }
    
    delete current->next;
    current->next = nullptr;
    return head;
}
```

### Delete After a Given Node
```cpp
void deleteAfter(ListNode* prevNode) {
    if (prevNode == nullptr || prevNode->next == nullptr) {
        return;
    }
    
    ListNode* nodeToDelete = prevNode->next;
    prevNode->next = nodeToDelete->next;
    delete nodeToDelete;
}
```

### Delete Node by Value
```cpp
ListNode* deleteByValue(ListNode* head, int val) {
    if (head == nullptr) return nullptr;
    
    // If head node contains the value
    if (head->val == val) {
        ListNode* newHead = head->next;
        delete head;
        return newHead;
    }
    
    ListNode* current = head;
    while (current->next != nullptr && current->next->val != val) {
        current = current->next;
    }
    
    if (current->next != nullptr) {
        ListNode* nodeToDelete = current->next;
        current->next = nodeToDelete->next;
        delete nodeToDelete;
    }
    
    return head;
}
```

### Delete Node at Position
```cpp
ListNode* deleteAtPosition(ListNode* head, int pos) {
    if (head == nullptr) return nullptr;
    
    if (pos == 0) {
        ListNode* newHead = head->next;
        delete head;
        return newHead;
    }
    
    ListNode* current = head;
    for (int i = 0; i < pos - 1 && current != nullptr; i++) {
        current = current->next;
    }
    
    if (current == nullptr || current->next == nullptr) {
        return head; // Position out of bounds
    }
    
    ListNode* nodeToDelete = current->next;
    current->next = nodeToDelete->next;
    delete nodeToDelete;
    
    return head;
}
```

## 🧪 Using a Dummy Node

```cpp
// Dummy node simplifies edge cases (especially for deletions)
ListNode* removeElements(ListNode* head, int val) {
    ListNode* dummy = new ListNode(0);
    dummy->next = head;
    ListNode* current = dummy;
    
    while (current->next != nullptr) {
        if (current->next->val == val) {
            ListNode* nodeToDelete = current->next;
            current->next = current->next->next;
            delete nodeToDelete;
        } else {
            current = current->next;
        }
    }
    
    ListNode* result = dummy->next;
    delete dummy;
    return result;
}

// Insert in sorted list using dummy node
ListNode* insertInSortedList(ListNode* head, int val) {
    ListNode* dummy = new ListNode(0);
    dummy->next = head;
    ListNode* current = dummy;
    
    // Find position to insert
    while (current->next != nullptr && current->next->val < val) {
        current = current->next;
    }
    
    // Insert new node
    ListNode* newNode = new ListNode(val);
    newNode->next = current->next;
    current->next = newNode;
    
    ListNode* result = dummy->next;
    delete dummy;
    return result;
}
```

## 🔄 Swapping Pairs of Nodes

```cpp
// LeetCode 24: Swap Nodes in Pairs
ListNode* swapPairs(ListNode* head) {
    ListNode* dummy = new ListNode(0);
    dummy->next = head;
    ListNode* prev = dummy;
    
    while (prev->next != nullptr && prev->next->next != nullptr) {
        // Nodes to be swapped
        ListNode* first = prev->next;
        ListNode* second = prev->next->next;
        
        // Swapping
        prev->next = second;
        first->next = second->next;
        second->next = first;
        
        // Move prev to end of swapped pair
        prev = first;
    }
    
    ListNode* result = dummy->next;
    delete dummy;
    return result;
}

// Alternative: Recursive approach
ListNode* swapPairsRecursive(ListNode* head) {
    if (head == nullptr || head->next == nullptr) {
        return head;
    }
    
    ListNode* second = head->next;
    head->next = swapPairsRecursive(second->next);
    second->next = head;
    
    return second;
}
```

## 🔁 Reversing a Linked List

### Iterative Approach
```cpp
ListNode* reverseList(ListNode* head) {
    ListNode* prev = nullptr;
    ListNode* current = head;
    
    while (current != nullptr) {
        ListNode* nextTemp = current->next;
        current->next = prev;
        prev = current;
        current = nextTemp;
    }
    
    return prev; // New head
}
```

### Recursive Approach
```cpp
ListNode* reverseListRecursive(ListNode* head) {
    // Base case
    if (head == nullptr || head->next == nullptr) {
        return head;
    }
    
    // Recursively reverse the rest
    ListNode* newHead = reverseListRecursive(head->next);
    
    // Reverse current connection
    head->next->next = head;
    head->next = nullptr;
    
    return newHead;
}
```

### Reverse Between Positions
```cpp
// LeetCode 92: Reverse Linked List II
ListNode* reverseBetween(ListNode* head, int left, int right) {
    if (left == right) return head;
    
    ListNode* dummy = new ListNode(0);
    dummy->next = head;
    ListNode* prev = dummy;
    
    // Move to position before 'left'
    for (int i = 0; i < left - 1; i++) {
        prev = prev->next;
    }
    
    ListNode* current = prev->next;
    
    // Reverse nodes from 'left' to 'right'
    for (int i = 0; i < right - left; i++) {
        ListNode* nextNode = current->next;
        current->next = nextNode->next;
        nextNode->next = prev->next;
        prev->next = nextNode;
    }
    
    ListNode* result = dummy->next;
    delete dummy;
    return result;
}
```

## 🔍 Finding the Middle Node

### Using Two Pointers (Tortoise and Hare)
```cpp
ListNode* findMiddle(ListNode* head) {
    if (head == nullptr) return nullptr;
    
    ListNode* slow = head;
    ListNode* fast = head;
    
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }
    
    return slow; // Middle node
}

// For even number of nodes, return the second middle
ListNode* findMiddleSecond(ListNode* head) {
    if (head == nullptr) return nullptr;
    
    ListNode* slow = head;
    ListNode* fast = head;
    
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }
    
    return slow;
}

// For even number of nodes, return the first middle
ListNode* findMiddleFirst(ListNode* head) {
    if (head == nullptr || head->next == nullptr) return head;
    
    ListNode* slow = head;
    ListNode* fast = head->next;
    
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }
    
    return slow;
}
```

### Using Length Count
```cpp
ListNode* findMiddleByCount(ListNode* head) {
    int length = 0;
    ListNode* current = head;
    
    // Count total nodes
    while (current != nullptr) {
        length++;
        current = current->next;
    }
    
    // Find middle position
    int middle = length / 2;
    current = head;
    
    for (int i = 0; i < middle; i++) {
        current = current->next;
    }
    
    return current;
}
```

## 🔗 Detecting a Cycle (Floyd's Algorithm)

### Basic Cycle Detection
```cpp
bool hasCycle(ListNode* head) {
    if (head == nullptr || head->next == nullptr) {
        return false;
    }
    
    ListNode* slow = head;
    ListNode* fast = head;
    
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
        
        if (slow == fast) {
            return true; // Cycle detected
        }
    }
    
    return false; // No cycle
}
```

### Finding Cycle Start Position
```cpp
ListNode* detectCycle(ListNode* head) {
    if (head == nullptr || head->next == nullptr) {
        return nullptr;
    }
    
    // Step 1: Detect if cycle exists
    ListNode* slow = head;
    ListNode* fast = head;
    
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
        
        if (slow == fast) {
            break; // Cycle found
        }
    }
    
    // No cycle
    if (fast == nullptr || fast->next == nullptr) {
        return nullptr;
    }
    
    // Step 2: Find start of cycle
    ListNode* start = head;
    while (start != slow) {
        start = start->next;
        slow = slow->next;
    }
    
    return start; // Start of cycle
}
```

### Cycle Length
```cpp
int cycleLength(ListNode* head) {
    if (!hasCycle(head)) return 0;
    
    ListNode* slow = head;
    ListNode* fast = head;
    
    // Find meeting point
    do {
        slow = slow->next;
        fast = fast->next->next;
    } while (slow != fast);
    
    // Count cycle length
    int length = 1;
    ListNode* current = slow->next;
    while (current != slow) {
        length++;
        current = current->next;
    }
    
    return length;
}
```

## 🔀 Merging Two Sorted Lists

### Iterative Approach
```cpp
ListNode* mergeTwoLists(ListNode* list1, ListNode* list2) {
    ListNode* dummy = new ListNode(0);
    ListNode* current = dummy;
    
    while (list1 != nullptr && list2 != nullptr) {
        if (list1->val <= list2->val) {
            current->next = list1;
            list1 = list1->next;
        } else {
            current->next = list2;
            list2 = list2->next;
        }
        current = current->next;
    }
    
    // Attach remaining nodes
    if (list1 != nullptr) {
        current->next = list1;
    } else {
        current->next = list2;
    }
    
    ListNode* result = dummy->next;
    delete dummy;
    return result;
}
```

### Recursive Approach
```cpp
ListNode* mergeTwoListsRecursive(ListNode* list1, ListNode* list2) {
    if (list1 == nullptr) return list2;
    if (list2 == nullptr) return list1;
    
    if (list1->val <= list2->val) {
        list1->next = mergeTwoListsRecursive(list1->next, list2);
        return list1;
    } else {
        list2->next = mergeTwoListsRecursive(list1, list2->next);
        return list2;
    }
}
```

### Merge K Sorted Lists
```cpp
// Using divide and conquer
ListNode* mergeKLists(vector<ListNode*>& lists) {
    if (lists.empty()) return nullptr;
    return mergeKListsHelper(lists, 0, lists.size() - 1);
}

ListNode* mergeKListsHelper(vector<ListNode*>& lists, int start, int end) {
    if (start == end) return lists[start];
    if (start > end) return nullptr;
    
    int mid = start + (end - start) / 2;
    ListNode* left = mergeKListsHelper(lists, start, mid);
    ListNode* right = mergeKListsHelper(lists, mid + 1, end);
    
    return mergeTwoLists(left, right);
}

// Using priority queue (min-heap)
ListNode* mergeKListsPQ(vector<ListNode*>& lists) {
    auto compare = [](ListNode* a, ListNode* b) {
        return a->val > b->val;
    };
    
    priority_queue<ListNode*, vector<ListNode*>, decltype(compare)> pq(compare);
    
    // Add first node of each list
    for (ListNode* list : lists) {
        if (list != nullptr) {
            pq.push(list);
        }
    }
    
    ListNode* dummy = new ListNode(0);
    ListNode* current = dummy;
    
    while (!pq.empty()) {
        ListNode* node = pq.top();
        pq.pop();
        
        current->next = node;
        current = current->next;
        
        if (node->next != nullptr) {
            pq.push(node->next);
        }
    }
    
    ListNode* result = dummy->next;
    delete dummy;
    return result;
}
```

## 🧹 Memory Management & Utilities

### Delete Entire List
```cpp
void deleteList(ListNode* head) {
    while (head != nullptr) {
        ListNode* temp = head;
        head = head->next;
        delete temp;
    }
}
```

### Clone/Copy List
```cpp
ListNode* cloneList(ListNode* head) {
    if (head == nullptr) return nullptr;
    
    ListNode* newHead = new ListNode(head->val);
    ListNode* current = newHead;
    ListNode* original = head->next;
    
    while (original != nullptr) {
        current->next = new ListNode(original->val);
        current = current->next;
        original = original->next;
    }
    
    return newHead;
}
```

### Convert to Vector
```cpp
vector<int> listToVector(ListNode* head) {
    vector<int> result;
    ListNode* current = head;
    
    while (current != nullptr) {
        result.push_back(current->val);
        current = current->next;
    }
    
    return result;
}
```

## ⚡ Common Patterns & Tips

### Two-Pointer Technique
```cpp
// Fast and slow pointers for various problems
ListNode* slow = head;
ListNode* fast = head;

while (fast != nullptr && fast->next != nullptr) {
    slow = slow->next;          // Move 1 step
    fast = fast->next->next;    // Move 2 steps
}
// slow is at middle, fast detects cycles
```

### Dummy Node Pattern
```cpp
// Always use dummy node for head modifications
ListNode* dummy = new ListNode(0);
dummy->next = head;
// ... perform operations
ListNode* result = dummy->next;
delete dummy;
return result;
```

### Previous Node Tracking
```cpp
// Keep track of previous node for deletions
ListNode* prev = nullptr;
ListNode* current = head;

while (current != nullptr) {
    if (/* condition to delete */) {
        if (prev != nullptr) {
            prev->next = current->next;
        } else {
            head = current->next; // Deleting head
        }
        delete current;
        current = prev ? prev->next : head;
    } else {
        prev = current;
        current = current->next;
    }
}
```

## 🎯 Time Complexity Summary

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Traversal | O(n) | O(1) |
| Insert at beginning | O(1) | O(1) |
| Insert at end | O(n) | O(1) |
| Insert at position | O(n) | O(1) |
| Delete at beginning | O(1) | O(1) |
| Delete at end | O(n) | O(1) |
| Delete by value | O(n) | O(1) |
| Search | O(n) | O(1) |
| Reverse | O(n) | O(1) |
| Find middle | O(n) | O(1) |
| Detect cycle | O(n) | O(1) |
| Merge two sorted | O(n + m) | O(1) |

## 🚀 Related LeetCode Problems

- **21. Merge Two Sorted Lists** - Basic merging
- **24. Swap Nodes in Pairs** - Node manipulation
- **83. Remove Duplicates from Sorted List** - Deletion patterns
- **92. Reverse Linked List II** - Partial reversal
- **141. Linked List Cycle** - Cycle detection
- **142. Linked List Cycle II** - Find cycle start
- **143. Reorder List** - Complex manipulation
- **148. Sort List** - Merge sort on linked list
- **206. Reverse Linked List** - Basic reversal
- **234. Palindrome Linked List** - Two pointers + reversal