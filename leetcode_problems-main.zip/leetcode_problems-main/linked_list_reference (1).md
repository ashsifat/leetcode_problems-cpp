# Linked List in C++ – Quick Reference Guide

## 🔧 Basic Structure

```cpp
struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(nullptr) {}
};
```

## 🧱 Creating Nodes

```cpp
// Create a simple list: 1 -> 2 -> 3
ListNode* head = new ListNode(1);
head->next = new ListNode(2);
head->next->next = new ListNode(3);
```

## 🔁 Traversing a Linked List

```cpp
void printList(ListNode* head) {
    while (head) {
        cout << head->val << " ";
        head = head->next;
    }
}
```

## ➕ Inserting a Node After a Given Node

```cpp
void insertAfter(ListNode* prev, int val) {
    if (!prev) return;
    
    ListNode* newNode = new ListNode(val);
    newNode->next = prev->next;
    prev->next = newNode;
}
```

## ❌ Deleting a Node After a Given Node

```cpp
void deleteAfter(ListNode* prev) {
    if (!prev || !prev->next) return;
    
    ListNode* nodeToDelete = prev->next;
    prev->next = nodeToDelete->next;
    delete nodeToDelete;
}
```

## 🧪 Using a Dummy Node

```cpp
// Useful when head might change
ListNode* removeElements(ListNode* head, int val) {
    ListNode dummy(0);
    dummy.next = head;
    ListNode* curr = &dummy;
    
    while (curr->next) {
        if (curr->next->val == val) {
            ListNode* toDelete = curr->next;
            curr->next = curr->next->next;
            delete toDelete;
        } else {
            curr = curr->next;
        }
    }
    
    return dummy.next;
}
```

## 🔄 Swapping Pairs of Nodes

```cpp
// 1->2->3->4 becomes 2->1->4->3
ListNode* swapPairs(ListNode* head) {
    ListNode dummy(0);
    dummy.next = head;
    ListNode* prev = &dummy;
    
    while (prev->next && prev->next->next) {
        ListNode* first = prev->next;
        ListNode* second = prev->next->next;
        
        prev->next = second;
        first->next = second->next;
        second->next = first;
        
        prev = first;
    }
    
    return dummy.next;
}
```

## 🔁 Reversing a Linked List

```cpp
// 1->2->3 becomes 3->2->1
ListNode* reverse(ListNode* head) {
    ListNode* prev = nullptr;
    ListNode* curr = head;
    
    while (curr) {
        ListNode* next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    
    return prev;
}
```

## 🔍 Finding the Middle Node

```cpp
// Slow/fast pointer technique
ListNode* findMiddle(ListNode* head) {
    ListNode* slow = head;
    ListNode* fast = head;
    
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    
    return slow;
}
```

## 🔗 Detecting a Cycle (Floyd's Algorithm)

```cpp
bool hasCycle(ListNode* head) {
    ListNode* slow = head;
    ListNode* fast = head;
    
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;
    }
    
    return false;
}
```

## 🔀 Merging Two Sorted Lists

```cpp
ListNode* mergeTwoLists(ListNode* l1, ListNode* l2) {
    ListNode dummy(0);
    ListNode* curr = &dummy;
    
    while (l1 && l2) {
        if (l1->val <= l2->val) {
            curr->next = l1;
            l1 = l1->next;
        } else {
            curr->next = l2;
            l2 = l2->next;
        }
        curr = curr->next;
    }
    
    curr->next = l1 ? l1 : l2;
    return dummy.next;
}
```

## ⚡ Key Patterns

### Two Pointer Template
```cpp
ListNode* slow = head;
ListNode* fast = head;

while (fast && fast->next) {
    slow = slow->next;        // 1 step
    fast = fast->next->next;  // 2 steps
}
```

### Dummy Node Template
```cpp
ListNode dummy(0);
dummy.next = head;
ListNode* curr = &dummy;
// ... operations
return dummy.next;
```

### Basic Operations Template
```cpp
while (curr) {
    // Process current node
    curr = curr->next;
}
```

## 🎯 Time Complexity

| Operation | Time | Space |
|-----------|------|-------|
| Traverse | O(n) | O(1) |
| Insert | O(1) | O(1) |
| Delete | O(1) | O(1) |
| Search | O(n) | O(1) |
| Reverse | O(n) | O(1) |
| Find Middle | O(n) | O(1) |
| Cycle Detection | O(n) | O(1) |
| Merge | O(n+m) | O(1) |